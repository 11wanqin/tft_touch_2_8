#ifndef _main_H
#define _main_H

#include <stm32f10x.h>
#include "delay.h"
#include "st7789v.h"
#include "usart.h"
#include <stdio.h>

#endif
